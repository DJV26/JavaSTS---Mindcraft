import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) throws SQLException {
		int roll, marks;
		String name;
		PreparedStatement psmt;
		ResultSet rs;
		boolean s;
		Scanner sc = new Scanner(System.in);
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/student","root","root");

		while(true) {
			System.out.println("1. Insert Record");
			System.out.println("2. Update Record");
			System.out.println("3. Delete Record");
			System.out.println("4. Display Particluar Record");
			System.out.println("5. Display All Record");
			System.out.println("6. EXIT");
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter Roll no, Name, Marks");
				roll = sc.nextInt();
				name = sc.next();
				marks = sc.nextInt();
				psmt = c.prepareStatement("insert into details values (?,?,?)");
				psmt.setInt(1, roll);
				psmt.setString(2, name);
				psmt.setInt(3, marks);
				s = psmt.execute();
				if(!s) {
					System.out.println("Row Inserted Successfully");
				}
				break;
			case 2:
				System.out.println("Enter Roll Number to update details");
				roll = sc.nextInt();
				System.out.println("Enter UPDATED Name and Marks");
				name = sc.next();
				marks = sc.nextInt();
				psmt = c.prepareStatement("update details set fullname = (?), marks = (?) where stid = (?)");
				psmt.setInt(3, roll);
				psmt.setString(1, name);
				psmt.setInt(2, marks);
				s = psmt.execute();
				if(!s) {
					System.out.println("Row Updated Successfully");
				}
				break;
			case 3:
				System.out.println("Enter Roll Number to Delete details");
				roll = sc.nextInt();
				psmt = c.prepareStatement("delete from details where stid = (?)");
				psmt.setInt(1, roll);
				s = psmt.execute();
				if(!s) {
					System.out.println("Row Delete Successfully");
				}
				break;
			case 4:
				System.out.println("Enter Roll Number to View Details");
				roll = sc.nextInt();
				psmt = c.prepareStatement("select * from details where stid = (?)");
				psmt.setInt(1, roll);
				rs = psmt.executeQuery();
				while(rs.next())  {
					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
				}
				System.out.println();
				break;
			case 5:	
				System.out.println("View Details");
				psmt = c.prepareStatement("select * from details");
				rs = psmt.executeQuery();
				while(rs.next())  {
					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
				}
				System.out.println();
				break;
			case 6:
				c.close();
				System.exit(0);
			}
	}
}}

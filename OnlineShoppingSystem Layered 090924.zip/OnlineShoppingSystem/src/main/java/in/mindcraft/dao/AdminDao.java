package in.mindcraft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.mindcraft.pojos.Admin;
import in.mindcraft.pojos.Cart;
import in.mindcraft.pojos.Customer;
import in.mindcraft.pojos.Product;
import in.mindcraft.utils.DButils;

public class AdminDao {

	private Connection cn;
	private PreparedStatement pst1;

	public void loginadmin(Admin admin) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("select id from adminlogin where id=(?) and pwd = (?)");
		//pst1.setInt(1, customer.getCid());
		pst1.setString(1, admin.getUname());
		pst1.setString(2, admin.getPwd());
//		pst1.setDouble(4, customer.getWallet());
//		pst1.setDouble(5, customer.getCart());
		pst1.execute();
		DButils.closedConnection();
	}
	
//	public void addproduct(Product product) throws SQLException, ClassNotFoundException {
//		// TODO Auto-generated method stub
//		cn = DButils.openConnection();  //Inversion of Control
//		//pst1 = cn.prepareStatement("select id from product where id=(?), pwd = (?)");
//		//pst1.setInt(1, customer.getCid());
//	//	pst1.setString(1, product.getUname());
//		//pst1.setString(2, product.getPwd());
////		pst1.setDouble(4, customer.getWallet());
////		pst1.setDouble(5, customer.getCart());
//		pst1.execute();
//		DButils.closedConnection();
//	}
	
	public void viewcustomers(Customer customer) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("select id from adminlogin where id=(?) and pwd = (?)");
		//pst1.setInt(1, customer.getCid());
//		pst1.setString(1, customer.getUname());
//		pst1.setString(2, customer.getPwd());
////		pst1.setDouble(4, customer.getWallet());
////		pst1.setDouble(5, customer.getCart());
		pst1.execute();
		DButils.closedConnection();
	}

	public List<Product> viewproduct() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("select * from product");
		//System.out.println("llkk;llk");
		List<Product> list = new ArrayList<Product>();
		ResultSet rs = pst1.executeQuery();
		//System.out.println("llkk;llk");
		while(rs.next())  {
				list.add(new Product(rs.getInt(1), rs.getString(2)  ,rs.getInt(3)));
		}
		//System.out.println("llkk;llk");
		return list;
	}
	
	public void addProduct(Product product) throws SQLException, ClassNotFoundException {
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("insert into product values (?,?,?)");
		pst1.setInt(1, product.getPno());
		pst1.setString(2, product.getPname());
		pst1.setInt(3, product.getPprice());
		pst1.execute();
		DButils.closedConnection();
	}
}

package in.mindcraft.dao;

public class ProductDao {

}

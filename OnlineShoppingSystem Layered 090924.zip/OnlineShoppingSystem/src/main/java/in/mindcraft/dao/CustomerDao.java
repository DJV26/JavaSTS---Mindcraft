package in.mindcraft.dao;

import in.mindcraft.pojos.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

import in.mindcraft.utils.DButils;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.servlet.ModelAndView;

public class CustomerDao {

	private Connection cn;
	
	private PreparedStatement pst1;
	
	public void addcustomer(Customer customer) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("insert into customer values(?,?,?,?,?)");
		pst1.setInt(1, customer.getCid());
		pst1.setString(2, customer.getUname());
		pst1.setString(3, customer.getPwd());
		pst1.setDouble(4, customer.getWallet());
		pst1.setDouble(5, customer.getCart());
		pst1.execute();
		DButils.closedConnection();
	}
	
	public void logincustomer(Customer customer) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("select * from custlogin where uname=(?) and pwd = (?)");
		//pst1.setInt(1, customer.getCid());
		pst1.setString(1, customer.getUname());
		pst1.setString(2, customer.getPwd());

		boolean isValid = false;
        ResultSet rs = pst1.executeQuery();
            isValid = rs.next(); // If there is a result, the credentials are valid
            if (!isValid) {
            	System.out.println("hbdhwdh");
        		ModelAndView mv = new ModelAndView();
        		System.out.println();
        		mv.setViewName("index.jsp");
            }
		DButils.closedConnection();
	}
	
	public void addproducttocart(Cart cart) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		List<Cart> list = new ArrayList<Cart>();
		pst1 = cn.prepareStatement("insert into cart values (?,?,?)");
		pst1.setInt(1, cart.getPid());
		pst1.setDouble(2, cart.getPprice());
		pst1.setInt(3, cart.getQuantity());
		pst1.execute();
		DButils.closedConnection();
	}
	
	public void addbalance(int balance) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("update custlogin set wallet = wallet+(?) where id=1");
		pst1.setInt(1, balance);
		pst1.execute();
		DButils.closedConnection();
	}
	
	public List<Cart> viewcart() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		pst1 = cn.prepareStatement("select * from cart");
		List<Cart> list = new ArrayList<Cart>();
		ResultSet rs = pst1.executeQuery();
		while(rs.next())  {
				list.add(new Cart(rs.getInt(1), rs.getDouble(2), rs.getInt(3)));
		}
		//DButils.closedConnection();
		DButils.closedConnection();
		return list;
	}

	public List<Customer> viewcustomers() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		cn = DButils.openConnection();  //Inversion of Control
		List<Customer> list = new ArrayList<Customer>();
		pst1 = cn.prepareStatement("select * from custlogin");

		ResultSet rs = pst1.executeQuery();
		while(rs.next())  {
				list.add(new Customer(rs.getInt(1), rs.getString(4), rs.getInt(5)));
		}
		DButils.closedConnection();
		return list;
	}

	public List<Cart> viewBill() throws SQLException, ClassNotFoundException {
		cn = DButils.openConnection();  //Inversion of Control
		List<Cart> list = new ArrayList<Cart>();
		pst1 = cn.prepareStatement("select * from cart");
		ResultSet rs = pst1.executeQuery();
		while(rs.next())  {
				list.add(new Cart(rs.getInt(1), rs.getDouble(2), rs.getInt(3)));
		}
		DButils.closedConnection();
		return list;
	}
}

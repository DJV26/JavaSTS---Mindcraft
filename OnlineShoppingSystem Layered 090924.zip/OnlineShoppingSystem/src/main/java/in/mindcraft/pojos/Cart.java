package in.mindcraft.pojos;

public class Cart {
	private int pid;
	private double pprice;
	private int quantity;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public double getPprice() {
		return pprice;
	}
	public void setPprice(double pprice) {
		this.pprice = pprice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Cart(int pid, double pprice, int quantity) {
		super();
		this.pid = pid;
		this.pprice = pprice;
		this.quantity = quantity;
	}
	
}


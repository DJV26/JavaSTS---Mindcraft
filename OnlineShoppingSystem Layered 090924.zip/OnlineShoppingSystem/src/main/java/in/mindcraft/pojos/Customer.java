package in.mindcraft.pojos;

public class Customer {
	private int cid;
	private String cname;
	private int wallet;
	private String uname;
	private String pwd;
	private double cart;
	private int balance;
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getWallet() {
		return wallet;
	}
	public void setWallet(int wallet) {
		this.wallet = wallet;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String id) {
		this.uname = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Customer(int cid, String cname, int wallet) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.wallet = wallet;
	}
	
	public Customer(String id, String pwd) {
		this.uname = id;
		this.pwd = pwd;
	}
	public double getCart() {
		// TODO Auto-generated method stub
		return cart;
	}
	public Customer(int cid, String cname,int wallet, String uname, String pwd, double cart) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.wallet = wallet;
		this.uname = uname;
		this.pwd = pwd;
		this.cart = cart;
	}
	public Customer(int balance) {
		// TODO Auto-generated constructor stub
		this.balance  = balance;
	}
	
}

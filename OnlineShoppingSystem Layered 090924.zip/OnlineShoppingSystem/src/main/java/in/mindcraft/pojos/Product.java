package in.mindcraft.pojos;

public class Product {
	private int pno;
	private String pname;
	private int pprice;
//	private int quantity;
//	private double discount;
	
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPprice() {
		return pprice;
	}
	public void setPprice(int pprice) {
		this.pprice = pprice;
	}
//	public int getQuantiity() {
//		return quantity;
//	}
//	public void setQuality(int quantiity) {
//		this.quantity = quantiity;
//	}
//	public double getDiscount() {
//		return discount;
//	}
//	public void setDiscount(double discount) {
//		this.discount = discount;
//	}
	
//	public Product(int pno, String pname, int pprice, int quantity, double discount) {
//		super();
//		this.pno = pno;
//		this.pname = pname;
//		this.pprice = pprice;
//		this.quantity = quantity;
//		this.discount = discount;
//	}
	
	public Product(int pno, String pname, int pprice) {
		this.pno = pno;
		this.pname = pname;
		this.pprice = pprice;
	}
//	public Product(int int1, int int2) {
//		// TODO Auto-generated constructor stub
//		int1 = pno;
//		int2 = pprice;
//	}
}

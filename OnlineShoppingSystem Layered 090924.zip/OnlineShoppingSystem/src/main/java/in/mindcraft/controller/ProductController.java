package in.mindcraft.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ProductController {

}

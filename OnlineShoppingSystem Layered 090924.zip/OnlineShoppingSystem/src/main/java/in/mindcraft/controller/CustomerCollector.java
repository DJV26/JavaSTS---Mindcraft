package in.mindcraft.controller;

import java.sql.SQLException; 
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import in.mindcraft.dao.CustomerDao;
import in.mindcraft.pojos.Cart;
import in.mindcraft.pojos.Customer;
import in.mindcraft.pojos.Product;

@Controller
public class CustomerCollector {

	private CustomerDao customerdao = new CustomerDao();

	@RequestMapping("/custlogin")
	public ModelAndView custlogin(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		Customer customer = new Customer(id, pwd);
		customerdao.logincustomer(customer);
		ModelAndView mv = new ModelAndView();
		//System.out.println();
		//List<Customer> list = customerdao.viewcustomers();
		mv.setViewName("cust.jsp");			
		return mv;
	}
	
	@RequestMapping("/addproducttocart")
	public void addproducttocart(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		int id = Integer.parseInt(request.getParameter("pno"));
		double price = Double.parseDouble(request.getParameter("pprice"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		Cart cart = new Cart(id, price, quantity);
		customerdao.addproducttocart(cart);
		
	}
	
	@RequestMapping("/addbalance")
	public void addbalance(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		int balance = Integer.parseInt(request.getParameter("addbal"));
		//int cid = Integer.parseInt(request.getParameter("cid"));
		//CustomerDao customerDao = new CustomerDao();
		//Customer customer = new Customer(balance);
		customerdao.addbalance(balance);
	}
	
	@RequestMapping("/viewcart")
	public ModelAndView viewcart(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		try {
			List<Cart> list = customerdao.viewcart();
			System.out.println();
			mv.setViewName("result.jsp");
			mv.addObject("list", list);
			}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/viewbill")
	public ModelAndView viewbill() throws SQLException, ClassNotFoundException {
		ModelAndView mv = new ModelAndView();
		//mv.setViewName("bill.jsp");	
		try {
			List<Cart> list = customerdao.viewBill();
			System.out.println();
			mv.setViewName("bill.jsp");
			mv.addObject("list", list);
			}
		catch(SQLException e) {
			e.printStackTrace();
		}
		//System.out.println(mv);	
		return mv;
//		while(mv.hasNext()) {
//			String l = it1.next();
//			System.out.println(l);
}
}

package in.mindcraft.controller;

import java.sql.SQLException; 
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import in.mindcraft.dao.AdminDao;
import in.mindcraft.dao.CustomerDao;
import in.mindcraft.pojos.Admin;
import in.mindcraft.pojos.Cart;
import in.mindcraft.pojos.Customer;
import in.mindcraft.pojos.Product;

@Controller
public class AdminController {
	
	private AdminDao admindao = new AdminDao();

	@RequestMapping("/adminlogin")
	public ModelAndView adminlogin(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		Admin admin = new Admin(id, pwd);
		AdminDao adminDao = new AdminDao();
		adminDao.loginadmin(admin);
		ModelAndView mv = new ModelAndView();
		System.out.println();
		mv.setViewName("admin.jsp");			
		return mv;
	}
	
	@RequestMapping("/addproduct")
	public void addproduct(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		int pno = Integer.parseInt(request.getParameter("pno"));
		String pname = request.getParameter("pname");
		int pprice = Integer.parseInt(request.getParameter("pprice"));
		Product product = new Product(pno, pname, pprice);
		//AdminDao adminDao = new AdminDao();
		admindao.addProduct(product);
	}
	
	
	@RequestMapping("/addcustomer")
	public void addcustomer(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		
	}

	@RequestMapping("/viewproduct")
	public ModelAndView viewproduct(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
			ModelAndView mv = new ModelAndView();
			System.out.println("nhsdcghjcgdsjgsjdc");
//				List<Product> list = admindao.viewproduct();
//				System.out.println(list);
//				return list;
//				mv.setViewName("result.jsp");
				try {
					List<Product> list = admindao.viewproduct();
					//System.out.println("jjjjj");
					//return list;
					mv.setViewName("prod.jsp");
					mv.addObject("list", list);

				}
				catch(SQLException e) {
					
				}
				return mv;
		}
	
	@RequestMapping("/viewcusromers")
	public void viewcustomers(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException {
		
	}
	
}

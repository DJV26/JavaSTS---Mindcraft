import java.util.Scanner;

class Transpose {
	int [][]b = new int[3][3];
	Scanner sc = new Scanner(System.in);
	public void Tr(int a[][]) {
		for (int i=0;i<a.length;i++) {
			for (int j=0;j<a[i].length;j++) {
				b[j][i] = a[i][j];
			}
		}
		System.out.println();
		System.out.println("TRANSPOSE MATRIX IS");
		for(int [] temp:b) {   // For each loop
			for(int val:temp) {
				System.out.print(val+" ");
			}
			System.out.println();
		}
		
	}
	
	public void AddMatrix() {
		int [][]m = new int[3][3];
		int [][]sum = new int[3][3];
		System.out.println("Enter a new 3X3 Matrix - Row-wise");
		for (int i=0;i<m.length;i++) {
			for (int j=0;j<m[i].length;j++) {
				m[i][j] = sc.nextInt();
			}
		}
		for (int i=0;i<m.length;i++) {
			for (int j=0;j<m[i].length;j++) {
				sum[i][j] = m[i][j] + b[i][j];
			}
		}
		System.out.println();
		System.out.println("SUM IS");
		for(int [] temp:sum) {   // For each loop
			for(int val:temp) {
				System.out.print(val+" ");
			}
			System.out.println();
	}}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]m = new int[3][3];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 3X3 Matrix - Row-wise");
		for (int i=0;i<m.length;i++) {
			for (int j=0;j<m[i].length;j++) {
				m[i][j] = sc.nextInt();
			}
		}
		System.out.println("ok");
		for(int [] temp:m) {   // For each loop
			for(int val:temp) {
				System.out.print(val+" ");
			}
			System.out.println();
		}
		Transpose t1 = new Transpose();
		t1.Tr(m);
		t1.AddMatrix();
	}

}


class Generic<G> {
	G g1;
	G g2;
	
	Generic(G g1) { 
		this.g1=g1;
	}
	
	public void hello() {
		System.out.println(g1);
	}
	

}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Generic<Integer> g1 = new Generic<Integer>(10);
		Generic<String> g2 = new Generic<String>("HELLO");
		g1.hello();
		g2.hello();
		}

}

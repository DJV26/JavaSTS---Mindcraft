import java.util.Scanner;

class Number {
	public void findMax(int a[]) {
		int max = a[0];
		for(int i=0;i<a.length;i++) {
				if (a[i]>max) {
					max = a[i];
			}
 		}
		System.out.println("Max is " +max);
	}
	
	public void findMin(int a[]) {
		int min = a[0];
		for(int i=0;i<a.length;i++) {
				if (a[i]<min) {
					min = a[i];
			}
 		}
		System.out.println("Min is " +min);
	}
	
	public void newArray(int a[]) {
		int[]b = new int[a.length];
		for(int i=0;i<a.length;i++) {
			b[i] = a[i]*5;
		}
		System.out.println("Array B is");
		for(int val:b) {    // For each loop
			System.out.print(val+" ");
		}	}
}
	
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = new int[5];
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 5 Numbers");
		for (int i=0;i<a.length;i++) {
			a[i] = sc.nextInt();
		}
		Number a1 = new Number();
		a1.findMax(a);
		a1.findMin(a);
		a1.newArray(a);
	}
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]a = {{1,2,3},{4,5,6},{7,8,9}};  // 3X3 Array
		int [][]b = {{1,2,3,4},{5,6,7},{8,9}}; // Jagged Array
		int [][]c = new int[3][4]; // 3r rows, 4 columns
		int [][]d = new int[3][]; // 3 rows, undefined columns
		
		for(int i=0;i<a.length;i++) {  //For loop
			for(int j=0;j<a[i].length;j++) {
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
			
		}
		System.out.println();
		for(int [] temp:b) {   // For each loop
			for(int val:temp) {
				System.out.print(val+" ");
			}
			System.out.println();
		}
	}

}

import java.util.Scanner;

class car { 
	String brand;
	String model;
	int year;
	
	car() {  // Default Constructor //No need to write methods, direct call constructor
		brand="tata";
		model="suv";
		year=2023;
		System.out.println(brand+" "+model+" "+year);
	}
	
	car(String b, String m, int y) {  // Parametrized Constructor
		brand = b;
		model = m;
		year = y;
	}
	
	public void display() {
		System.out.println(brand+" "+model+" "+year);
	}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		car c1 = new car("maruti","suv",2020);
		car c2 = new car();

//		c1.display();
//		c1.display();
	}

}

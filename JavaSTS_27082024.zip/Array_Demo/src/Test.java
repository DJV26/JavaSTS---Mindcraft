import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = new int[5];
		int [] b = {10,20,30};
		
		Scanner sc = new Scanner(System.in);
		for (int i=0;i<a.length;i++) {
			a[i] = sc.nextInt();
		}
		
		for(int val:a) {    // For each loop
			System.out.println(val);
		}
	}

}

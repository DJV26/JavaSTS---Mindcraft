package com.mindcraft.pack1;

public class Student {
	int roll_no;
	String name;
	
	public Student(int roll_no, String name) {
		this.name = name;
		this.roll_no = roll_no;
	}
	
    public void display() {
        System.out.println("Student [RollNo=" + roll_no + ", Name=" + name + "]");
    }
}

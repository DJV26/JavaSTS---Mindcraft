import java.util.Scanner;

class Student {
	int roll_no;
	String name;
	double percent;
	static int count = 0;
	
	public Student(int roll_no, String name, double percent) {
		this.roll_no = roll_no;
		this.name = name;
		this.percent = percent;
		count++;
	}

	public int getRoll_no() {
		return roll_no;
	}

	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPercent() {
		return percent;
	}

	public void setPercent(double percent) {
		this.percent = percent;
	}
	
	public void details() { 
		System.out.println(roll_no+"\t"+name+"\t"+percent);
	}

    public static int getCount() {
        return count;
    }
    
	@Override
	public String toString() {
		return "Student [roll_no=" + roll_no + ", name=" + name + ", percent=" + percent + "]";
	}
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice, cnt=0;
		Student det[] = new Student[10];
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("1. Add Student Details");
			System.out.println("2. Count objects");
			System.out.println("3. SHow Student Details");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter Roll Number, Student Name, Percentage");
				det[cnt++] = new Student(sc.nextInt(), sc.next(), sc.nextDouble());
				break;
			case 2:
				System.out.println("Count of students is " +Student.getCount());
				break;
			case 3:
				System.out.println("All Student details");
				for(int i=0;i<cnt;i++) {
					det[i].details();
				}
				break;
			case 4:
				System.exit(0);
	}

}
	}
}

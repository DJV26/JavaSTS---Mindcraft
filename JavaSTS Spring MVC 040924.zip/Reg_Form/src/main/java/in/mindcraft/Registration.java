package in.mindcraft;

import java.util.function.ToDoubleFunction;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Registration {
	
	@RequestMapping("/register")
	public ModelAndView register(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("ADDITION");
		String name = request.getParameter("name");
		// double mobile = Double.parseDouble(getParameter("mobile"));
		int mobile = 99;
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("name",name);
		mv.addObject("email",email);
		mv.addObject("mobile",mobile);
		mv.addObject("gender",gender);

		return mv;
	}

	private String getParameter(String string) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
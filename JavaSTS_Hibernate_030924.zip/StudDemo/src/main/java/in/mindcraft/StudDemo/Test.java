package in.mindcraft.StudDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student();
		s1.setSid(1);
		s1.setSname("Devansh");
		
		Student s2 = new Student();
		s2.setSid(2);
		s2.setSname("Aryan");
		
		Student s3 = new Student();
		s3.setSid(3);
		s3.setSname("Nikhil");
		
		Laptop l1 = new Laptop();
		l1.setLid(11);
		l1.setLname("HP");
		l1.setLmake(10000);
		
		Laptop l2 = new Laptop();
		l2.setLid(101);
		l2.setLname("Lenovo");
		l2.setLmake(12000);
		
		s1.getLaptop().add(l1);
		s1.getLaptop().add(l2);
		s2.getLaptop().add(l2);
		
//		l1.getStudent().add(s1);
//		l1.getStudent().add(s2);

		l1.getStudent().add(s1);
		l1.getStudent().add(s2);
		l2.getStudent().add(s3);

		
		Configuration con = new Configuration().configure();
		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
				.configure()
				.build();
		
		MetadataSources metadataSources = new MetadataSources(standardRegistry);

		Metadata metadata = metadataSources.getMetadataBuilder().build();

		SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(s1);
		session.save(s2);
		session.save(l1);
		session.save(l2);
		session.save(s3);
		

		transaction.commit();
		
		session.close();
		sessionFactory.close();
	}

}

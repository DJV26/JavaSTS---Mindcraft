package in.mindcraft.StudDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Laptop {
	@Id
	private int Lid;
	private String Lname;
	private int Lmake;
	
	@ManyToMany
	//@OneToMany
	//@OneToMany
	private List<Student> student = new ArrayList<Student>();

	public List<Student> getStudent() {
		return student;
	}

	public void setStudent(List<Student> student) {
		this.student = student;
	}

	public int getLid() {
		return Lid;
	}

	public void setLid(int lid) {
		Lid = lid;
	}

	public String getLname() {
		return Lname;
	}

	public void setLname(String lname) {
		Lname = lname;
	}

	public int getLmake() {
		return Lmake;
	}

	public void setLmake(int lmake) {
		Lmake = lmake;
	}

//	public List<Student> getStudent() {
//		return student;
//	}
//
//	public void setStudent(List<Student> student) {
//		this.student = student;
//	}
	
	
	
}

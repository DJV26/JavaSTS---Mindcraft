package in.mindcraft.StudDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Student {
	@Id
	private int sid;
	private String sname;
	
	@ManyToMany
	//@ManyToOne
	//@OneToMany
	private List<Laptop> laptop = new ArrayList<Laptop>();

//	@ManyToMany
//	private List<Laptop> laptopmanytomany = new ArrayList<Laptop>();
	
//	@ManyToOne
//	private List<Laptop> laptopmanytoone = new ArrayList<Laptop>();
	
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public List<Laptop> getLaptop() {
		return laptop;
	}

	public void setLaptop(List<Laptop> laptoponetomany) {
		this.laptop = laptoponetomany;
	}

//	public List<Laptop> getLaptopmanytomany() {
//		return laptopmanytomany;
//	}
//
//	public void setLaptopmanytomany(List<Laptop> laptopmanytomany) {
//		this.laptopmanytomany = laptopmanytomany;
//	}

//	public List<Laptop> getLaptopmanytoone() {
//		return laptopmanytoone;
//	}
//
//	public void setLaptopmanytoone(List<Laptop> laptopmanytoone) {
//		this.laptopmanytoone = laptopmanytoone;
//	}


	
}

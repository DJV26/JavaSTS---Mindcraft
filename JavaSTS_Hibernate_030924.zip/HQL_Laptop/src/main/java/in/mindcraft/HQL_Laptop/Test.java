package in.mindcraft.HQL_Laptop;

import java.util.List;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		        Laptop m1 = new Laptop(1, "iPhone", 150000);
		        Laptop m2 = new Laptop(2, "Samsung", 100000);
		        Laptop m3 = new Laptop(3, "OnePlus", 45000);

		       
		        // Create a StandardServiceRegistry
		        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
		                .configure() // This reads hibernate.cfg.xml
		                .build();

		        // Create MetadataSources
		        MetadataSources metadataSources = new MetadataSources(standardRegistry);

		        // Create Metadata
		        Metadata metadata = metadataSources.getMetadataBuilder().build();

		        // Create SessionFactory
		        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

		        // Open a session and begin a transaction
		        Session session = sessionFactory.openSession();
		        Transaction transaction = session.beginTransaction();


		        // Save mobile phone objects
//		        session.save(m1);
//		        session.save(m2);
//		        session.save(m3);

		        // HQL Query to retrieve mobile phones with cost >= 100000
		        Query<Laptop> q = session.createQuery("from Laptop where price >= 100000", Laptop.class);
		        List<Laptop> mlist = q.list();
		        for (Laptop m : mlist)
		            System.out.println(m);

		        //transaction.commit();

		        Scanner sc = new Scanner(System.in);
		        int choice;

		        // Menu for user actions
		        while (true) {
		            System.out.println("1. Delete Laptop Details:");
		            System.out.println("2. Exit:");
		            System.out.println("3. Insert Laptop Details:");
		            System.out.println("4. Update Laptop Details:");
		            System.out.println("Please select the Operation:");

		            choice = sc.nextInt();

		            switch (choice) {
		                case 1:
		                    System.out.println("Enter Laptop Id to delete:");
		                    int laptopIdToDelete = sc.nextInt();
		                    
		                    // Begin a new transaction for the delete operation
		                    transaction = session.beginTransaction();
		                    Query deleteQuery = session.createQuery("delete from Laptop where id = :laptopId");
		                    deleteQuery.setParameter("laptopId", laptopIdToDelete);
		                    int result = deleteQuery.executeUpdate();
		                    if (result > 0) {
		                        System.out.println("Laptopwith ID " + laptopIdToDelete + " deleted successfully.");
		                    } else {
		                        System.out.println("No Laptop found with ID " + laptopIdToDelete + ".");
		                    }
		                    transaction.commit();
		                    break;

		                case 2:
		                    session.close();
		                    sessionFactory.close();
		                    sc.close();
		                    System.exit(0);
		                    break;

		                case 3: 
		                    transaction = session.beginTransaction();
		                	System.out.println("Enter Laptop ID to add:");
		                	int id = sc.nextInt();
		                	System.out.println("Enter Laptop Name");
		                	String name = sc.next();
		                	System.out.println("Enter Laptop Price");
		                	int pr = sc.nextInt();
		    		        Laptop m4 = new Laptop(id, name, pr);
		    		        System.out.println("LAPTOP DETAILS INSERTED");
		    		        session.save(m4);
		    		        transaction.commit();
		    		        break;
		    		      
		                case 4:
		                    transaction = session.beginTransaction();
		                	System.out.println("Enter Laptop ID to update:");
		                	id = sc.nextInt();
		                	System.out.println("Enter UPDATED Laptop Name");
		                	name = sc.next();
		                	System.out.println("Enter UPDATED Laptop Price");
		                	pr = sc.nextInt();
		                	Query updateQuery = session.createQuery("update Laptop set name = :name, price = :price where id = :id");
		                	updateQuery.setParameter("name", name);
		                	updateQuery.setParameter("price", pr);
		                	updateQuery.setParameter("id", id);
		                    result = updateQuery.executeUpdate();
		                    if (result > 0) {
		                        System.out.println("Laptopwith ID " + id + " updated successfully.");
		                    } else {
		                        System.out.println("No Laptop found with ID " + id + ".");
		                    }
		                    transaction.commit();
		                    break;
		                default:
		                    System.out.println("Invalid choice. Please try again.");
		                    break;
		            }
		        }

	}

}

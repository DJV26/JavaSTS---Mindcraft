package in.mindcraft.EmpDemo;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
//import org.hibernate.service.ServiceRegistryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.Session;


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee e1 = new Employee();
		e1.setEmpid(1);
		e1.setName("Devansh");
		
		Employee e2 = new Employee();
		e2.setEmpid(2);
		e2.setName("Aryan");
		
		Address a1 = new Address();
		a1.setCity_id(1);;
		a1.setCity("Mumbai");
		a1.setStreet("Kachpada");
		a1.setState("Maharahstra");
		
		Address a2 = new Address();
		a2.setCity_id(2);;
		a2.setCity("Mbai");
		a2.setStreet("HELLO");
		a2.setState("Gujarat");
		
		e1.getList().add(a1);
		e1.getList().add(a2);

		
		Configuration con = new Configuration().configure();
		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
				.configure()
				.build();
		
		MetadataSources metadataSources = new MetadataSources(standardRegistry);

		Metadata metadata = metadataSources.getMetadataBuilder().build();

		SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(e1);
		session.save(e2);
		session.save(a1);
		session.save(a2);
		
		transaction.commit();
		
		session.close();
		sessionFactory.close();
				
	}

}

package in.mindcraft.BankAccountInheritance;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("Savings")
public class SavingsAccount extends Account {

    @Column(name = "interestRate")
    private int interestRate;

    // Getters and Setters
    public int getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(int interestRate) {
        this.interestRate = interestRate;
    }
}
package in.mindcraft.BankAccountInheritance;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue("Current")
@Table(name="Curr_Acc")
public class CurrentAccount extends Account {

    @Column(name = "overlimit")
    private double overlimit;

    // Getters and Setters
    public double getOverlimit() {
        return overlimit;
    }

    public void setOverlimit(double overlimit) {
        this.overlimit = overlimit;
    }
}

package in.mindcraft.BankAccountInheritance;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

//import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        
		    	
		        // Creating a base account
		        Account acc = new Account();
		        acc.setName("John Doe");
		        acc.setBalance(300);

		        // Creating a Savings Account
		        SavingsAccount sacc = new SavingsAccount();
		        sacc.setName("Jane Doe");
		        sacc.setBalance(500);
		        sacc.setInterestRate(10);

		        // Creating a Current Account
		        CurrentAccount cacc = new CurrentAccount();
		        cacc.setName("Jim Doe");
		        cacc.setBalance(1000);
		        cacc.setOverlimit(10000);

		        // Create a StandardServiceRegistry
		        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
		                .configure() // This reads hibernate.cfg.xml
		                .build();

		        // Create MetadataSources
		        MetadataSources metadataSources = new MetadataSources(standardRegistry);

		        // Create Metadata
		        Metadata metadata = metadataSources.getMetadataBuilder().build();

		        // Create SessionFactory
		        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

		        // Open a session and begin a transaction
		        Session session = sessionFactory.openSession();
		        Transaction transaction = session.beginTransaction();

		        // Save the objects
		        session.save(acc);
		        session.save(sacc);
		        session.save(cacc);

		        // Commit the transaction
		        transaction.commit();

		        // Close the session and session factory
		        session.close();
		        sessionFactory.close();
		    }
		}



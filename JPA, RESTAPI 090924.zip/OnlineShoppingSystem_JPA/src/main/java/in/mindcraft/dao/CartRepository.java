package in.mindcraft.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.mindcraft.entity.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {

}

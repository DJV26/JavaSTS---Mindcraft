package in.mindcraft.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import in.mindcraft.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	//public Customer findbyCid(int cid); 

}

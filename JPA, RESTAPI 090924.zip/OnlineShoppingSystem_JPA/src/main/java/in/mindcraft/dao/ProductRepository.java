package in.mindcraft.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import in.mindcraft.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	//public Product findbyPid(int pid); 

}

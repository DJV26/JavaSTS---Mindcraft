package in.mindcraft.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.mindcraft.entity.Customer;
import in.mindcraft.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/customer")
	public ResponseEntity<List<Customer>> getCustomer() {
		
		List<Customer> list=customerService.getallCustomers();
		if(list.size()<=0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		//return ResponseEntity.of(Optional.of(list));
		return ResponseEntity.status(HttpStatus.CREATED).body(list);
	}
	
	@PostMapping("/customer")
	public Customer addCustomer(@RequestBody Customer cust) {
		this.customerService.addCustomer(cust);
		return cust;
	}

	@DeleteMapping("/customer/{Id}")
	public void deleteCustomer(@PathVariable("Id") int cid) {
		this.customerService.deleteCustomer(cid);
	}
	
	@PutMapping("/customer/{cid}")
	public Customer upddateCustomer(@RequestBody Customer cust,@PathVariable("cid") int cid) {
		this.customerService.updateCustomer(cust, cid);
		return cust;
	}
	
}

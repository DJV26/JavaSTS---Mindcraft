package in.mindcraft.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.mindcraft.entity.Product;
import in.mindcraft.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	public ProductService productService;
	
	@GetMapping("/product")
	public ResponseEntity<List<Product>> getProduct() {
		List<Product> list = productService.getallProducts();
		
		if(list.size()<=0) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(list);
		}
	
	@PostMapping("/product/{pid}")
	public Product addProduct(@RequestBody Product prod) {
		this.productService.addProduct(prod);
		return prod;
	}
	
	@PutMapping("/product/{pid}")
	public Product updateProduct(@RequestBody Product prod, @PathVariable("pid") int pid) {
		this.productService.updateProduct(prod, pid);
		return prod;
	}
	
	@DeleteMapping("/product/{pid}")
	public void deleteProduct(@PathVariable("pid") int pid) {
		this.productService.deleteProduct(pid);
	}
}


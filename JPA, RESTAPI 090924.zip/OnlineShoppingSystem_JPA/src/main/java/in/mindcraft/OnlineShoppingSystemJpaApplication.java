package in.mindcraft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoppingSystemJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShoppingSystemJpaApplication.class, args);
	}

}

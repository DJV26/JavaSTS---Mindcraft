package in.mindcraft.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Cart {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int cid;
private int pid;
private String pname;
private double price;
private int quantity;
private double discount;
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public int getPid() {
	return pid;
}
public void setPid(int pid) {
	this.pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public double getDiscount() {
	return discount;
}
public void setDiscount(double discount) {
	this.discount = discount;
}
public Cart(int cid, int pid, String pname, double price, int quantity, double discount) {
	super();
	this.cid = cid;
	this.pid = pid;
	this.pname = pname;
	this.price = price;
	this.quantity = quantity;
	this.discount = discount;
}
@Override
public String toString() {
	return "Cart [cid=" + cid + ", pid=" + pid + ", pname=" + pname + ", price=" + price + ", quantity=" + quantity
			+ ", discount=" + discount + "]";
}
public Cart() {
	
}
}

package in.mindcraft.entity;

import org.hibernate.annotations.ValueGenerationType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cid;
	private String cname;
	private int cwallet;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCwallet() {
		return cwallet;
	}
	public void setCwallet(int cwallet) {
		this.cwallet = cwallet;
	}
	
	public Customer(int cid, String cname, int cwallet) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cwallet = cwallet;
	}
	
	public Customer() {
		super();
	}
}

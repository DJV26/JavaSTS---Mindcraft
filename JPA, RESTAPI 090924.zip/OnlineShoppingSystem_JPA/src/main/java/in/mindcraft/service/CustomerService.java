package in.mindcraft.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.mindcraft.dao.CustomerRepository;
import in.mindcraft.entity.Customer;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;

	public CustomerRepository getCustomerRepository() {
		return customerRepository;
	}

	public void setCustomerRepository(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}
	
	//add customer
	public Customer addCustomer(Customer cust) {
		Customer cus = customerRepository.save(cust);
		return cust;
	}
	
	//delete customer
	public void deleteCustomer(int cid) {
		customerRepository.deleteById(cid);
	}
	
	///update Customer
	public void updateCustomer(Customer cust, int cid) {
		cust.setCid(cid);
		customerRepository.save(cust);
	}
	
	// get Customers
	public CustomerService(CustomerRepository customerRepository) {
		// TODO Auto-generated constructor stub
		this.customerRepository = customerRepository;
	}
	
	public List<Customer> getallCustomers() {
		List<Customer> list = (List<Customer>)this.customerRepository.findAll();
		return list;
	}
}

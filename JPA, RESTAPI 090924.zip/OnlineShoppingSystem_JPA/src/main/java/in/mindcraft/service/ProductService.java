package in.mindcraft.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.mindcraft.dao.CustomerRepository;
import in.mindcraft.dao.ProductRepository;
import in.mindcraft.entity.Customer;
import in.mindcraft.entity.Product;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;

	public ProductRepository getproductRepository() {
		return productRepository;
	}

	public void setProductRepository(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}
	
	//add Product
	public Product addProduct(Product prod) {
		Product product = productRepository.save(prod);
		return prod;
	}
	
	//delete Product
	public void deleteProduct(int pid) {
		productRepository.deleteById(pid);
	}
	
	///update Product
	public void updateProduct(Product prod, int pid) {
		prod.setPid(pid);
		productRepository.save(prod);
	}
	
	// get Products
	public ProductService(ProductRepository productRepository) {
		// TODO Auto-generated constructor stub
		this.productRepository = productRepository;
	}
	
	public List<Product> getallProducts() {
		List<Product> list = (List<Product>)this.productRepository.findAll();
		return list;
	}
}

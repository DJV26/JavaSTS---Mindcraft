package in.mindcraft.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import in.mindcraft.Entity.Book;

@Component
public class BookService {
	public static List<Book> list=new ArrayList<>();
	
	static {
		list.add(new Book(10, "Harry", "Rowling", 1000));
		list.add(new Book(20, "Potter", "Rowling", 2000));
	}

	//get all Books
	public List<Book> getAllBook(){
		return list;
	}
	
	//get Book by id
		public Book getBookById(int id) {
			
			Book book=null;
			// lambda function
			book=list.stream().filter(e->e.getBid()==id).findFirst().get();
			return book;
		}
		
		//add new Book
		public void addEmp(Book b) {
			list.add(b);
		}
		
		//delete Book
		public void deleteBook(int bid) {
			list=list.stream().filter(book->book.getBid()!=bid).collect(Collectors.toList());
		}
		
		//update Book
		public void updateBook(Book book,int bId) {
			list=list.stream().map(b->{
				if(book.getBid()==bId) {
					b.setTitle(book.getTitle());
					b.setAuthor(book.getAuthor());
					b.setCost(book.getCost());
				}
				return b;
			}).collect(Collectors.toList());
		}
}

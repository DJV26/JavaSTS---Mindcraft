package in.mindcraft.Service;

import java.util.List;  

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.mindcraft.Dao.BookRepository;
import in.mindcraft.Entity.Book;

@Service
public class BookService {
	
	@Autowired
	private BookRepository bookRepository;
	
	public BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}
	
	public List<Book> getallBooks() {
		List<Book> list = (List<Book>)this.bookRepository.findAll();
		return list;
	}
	
	public Book getBookById(int bid) {
		Book book = null;
		try {
			book=this.bookRepository.findById(bid);
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return book;
	}
	
	public Book addBook(Book b) {
		Book result = bookRepository.save(b);
		return b;
	}
	
	public void deleteBook(int bid) {
		bookRepository.deleteById(bid);
	}
	
	public void updateBook(Book book, int bid) {
		book.setBid(bid);
		bookRepository.save(book);
	}
}

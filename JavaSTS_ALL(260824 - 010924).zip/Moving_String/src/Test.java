import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;

class MovingString extends Frame implements Runnable{

	private Thread t1, t2;
	private int x1, x2; // x co-ordinates of strings
	
	public MovingString() {
		x1=100;
		x2=300;
		t1 = new Thread(this, "t1");
		t2 = new Thread(this, "t2");
		t1.start();
		t2.start();
	}
	
	public void paint(Graphics g) {
		g.setFont(new Font("roman", 50, 50));
		g.setColor(Color.black);
		g.drawString("MindCraft", x1, 200);
		g.setColor(Color.yellow);
		g.drawString("Software", x2, 200);

	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			if(Thread.currentThread()==t1) {
				x1++;
				if(x1==getWidth()) {
					x1=0;
					try {
						Thread.sleep(30);
					}
					catch(Exception e) {
						e.printStackTrace();}
				}
			}
			else if (Thread.currentThread()==t2) {
				x2--;
				if(x2==0) {
					x2=this.getWidth();	
					try {
						Thread.sleep(30);
					}
					catch(Exception e) {
						e.printStackTrace();
						}
				}
			}
			repaint();
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MovingString ms = new MovingString();
		ms.setSize(500, 500);
		ms.setVisible(true);
	}

}

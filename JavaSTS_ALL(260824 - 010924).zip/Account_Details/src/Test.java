import java.util.Scanner;

class AccountHolder {
	private int ac_no;
	private String ac_name;
	private double balance;
	
	public AccountHolder(int ac_no, String ac_name, double balance) {
		this.ac_no = ac_no;
		this.ac_name = ac_name;
		this.balance = balance;
	}
	public int getAc_no() {
		return ac_no;
	}
	public void setAc_no(int ac_no) {
		this.ac_no = ac_no;
	}
	public String getAc_name() {
		return ac_name;
	}
	public void setAc_name(String ac_name) {
		this.ac_name = ac_name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		balance = amount + balance;
	}
	
	public void withdraw(double amount) {
		balance = balance - amount;
	}
	
	public void details() { 
		System.out.println(ac_no+"\t"+ac_name+"\t"+balance);
	}
}

public class Test {

	public static void main(String[] args) {   
		// TODO Auto-generated method stub
		int cnt = 0, choice, ac_no;
		AccountHolder acc[] = new AccountHolder[10];
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("1. Add Account Details");
			System.out.println("2. Display Account Details");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw Amount");
			System.out.println("5. Exit");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter Account Number, Holder Name, Balance");
				acc[cnt++] = new AccountHolder(sc.nextInt(), sc.next(), sc.nextDouble());
				break;
			case 2:
				System.out.println("All Account details");
				for(int i=0;i<cnt;i++) {
					acc[i].details();
				}
				break;
			case 3:
				System.out.println("Enter Account Number for Deposit");
				ac_no = sc.nextInt();
				int fl = 0;
				for(int i=0;i<cnt;i++) {
					if(ac_no == acc[i].getAc_no()) {
						fl = 1;
						System.out.println("Enter Deposit Ammount");
						acc[i].deposit(sc.nextDouble());
					}
				}
				if (fl==1) {
					System.out.println("Amount Depsoited");
				}
				else {
					System.out.println("Account Detail not found");
				}
				break;
				
			case 4:
				System.out.println("Enter Account Number for Withdraw");
				ac_no = sc.nextInt();
				int fla = 0;
				for(int i=0;i<cnt;i++) {
					if(ac_no == acc[i].getAc_no()) {
						fla = 1;
						System.out.println("Enter Withdrawal Amount");
						double wamt = sc.nextDouble();
						if(wamt<=acc[i].getBalance()) {
							acc[i].withdraw(wamt);
						}
						else {
							System.out.println("Insufficient Balance");
						}
					}
				}
				if (fla==1) {
					System.out.println("Amount Withdrawn");
				}
				else {
					System.out.println("Account Detail not found");
				}
				break;
				
			case 5:
				System.exit(0);
			}
			}
	}
}
import com.mindcraft.pack1.Student;
import com.mindcraft.pack2.Batch;

public class Test {
    public static void main(String[] args) {
        // Creating objects of Student and Batch classes
        Student student1 = new Student(1, "Devansh");
        Student student2 = new Student(2, "Aryan");

        Batch batch1 = new Batch("Computer Science", 30);
        Batch batch2 = new Batch("IT", 30);

        student1.display();
        student2.display();

        batch1.display();
        batch2.display();
    }
}

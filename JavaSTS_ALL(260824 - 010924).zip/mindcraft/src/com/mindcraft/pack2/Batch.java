package com.mindcraft.pack2;

public class Batch {
	String Coursename;
	int BatchStrength;
	
	public Batch(String cname, int batchstrength) {
		this.Coursename = cname;
		this.BatchStrength = batchstrength;
	}
	
    public void display() {
        System.out.println("Batch [BatchStrength=" + BatchStrength + ", Coursename=" + Coursename + "]");
    }
}


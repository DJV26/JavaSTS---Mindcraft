import java.util.Scanner;
	public class Date {
		private int dd,mm,yy; 

		public Date(int dd, int mm, int yy) {
			this.dd = dd;
			this.mm = mm;
			this.yy = yy;
		}
		
		public Date() {
		        this.dd = 1;
		        this.mm = 1;
		        this.yy = 2000;
		}
		
//	    public void accept() {
//	        Scanner sc = new Scanner(System.in);
//	        System.out.print("Enter day: ");
//	        this.dd = sc.nextInt();
//	        System.out.print("Enter month: ");
//	        this.mm = sc.nextInt();
//	        System.out.print("Enter year: ");
//	        this.yy = sc.nextInt();
//	    }
	    
	    public static int acceptdd() {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter date: ");
	        int dd = sc.nextInt();
			return dd;
	    }
	    public static int acceptmm() {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter month: ");
	        int mm = sc.nextInt();
			return mm;
	    }
	    public static int acceptyy() {
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Enter year: ");
	        int yy = sc.nextInt();
			return yy;
	    }
	    
		public void show() {
			System.out.println(dd+"/"+mm+"/"+yy);
		}
	}

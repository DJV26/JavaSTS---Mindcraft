import java.util.Scanner;

public class Test<G> {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 10;
		int [] studentsroll = new int[n];
		String [] studentsname = new String[n];
		int [] studentsdd = new int[n];
		int [] studentsmm = new int[n];
		int [] studentsyy = new int[n];
		int det = 0;
		
		for (int i=0;i<studentsroll.length;i++) {
	        System.out.println("Enter student details:");
			studentsname[i] = student1.acceptname();
			studentsroll[i] = student1.acceptroll();
//            studentsarray[i].accept();
			studentsdd[i] = Date.acceptdd();
			studentsmm[i] = Date.acceptmm();
			studentsyy[i] = Date.acceptyy();
			det++;
//            studentsarray[i].show();
			for (int j=0;j<det;j++) {
				System.out.println("Student Name :" +studentsname[j]);
				System.out.println("Roll no :" +studentsroll[j]);
				System.out.println("DOB :" +studentsdd[j]+"/"+studentsmm[j]+"/"+studentsyy[j]);
				System.out.println();
			}
		}
	}
}

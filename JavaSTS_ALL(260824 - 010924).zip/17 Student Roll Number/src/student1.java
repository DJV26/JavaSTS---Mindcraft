import java.util.Scanner;
public class student1 {
	String name;
	private Date dob;
	static int roll = 1;
	int rollno;
    Scanner sc = new Scanner(System.in);

//public void accept() {
//    this.rollno = roll++; 
//    System.out.print("Enter student name: ");
//    this.name = sc.nextLine();
//    this.dob = new Date(); 
//    System.out.println("Enter date of birth:");
//    this.dob.accept(); 
//}

public static int acceptroll() {
    int rollno = roll++; 
    return rollno;
}

public static String acceptname() {
    System.out.print("Enter student name: ");
    Scanner sc = new Scanner(System.in);
    String name = sc.nextLine();
    return name;
}

public void show() {
	System.out.println("Name :" +name);
	System.out.println("Roll Number :" +rollno);
	dob.show();
}
}

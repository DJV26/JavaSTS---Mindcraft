import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

class student {
	int roll;
	String name;
	int grade;
	double percent;
}

class Utility_List implements Comparable<Utility_List> {
	
	private List<student> lst = new ArrayList<student>();
	int roll;
	String name;
	int grade;
	double percent;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public double getPercent() {
		return percent;
	}

	public void setPercent(double percent) {
		this.percent = percent;
	}

	public Utility_List(int roll, String name, int grade, double percent) {
		this.roll = roll;
		this.name = name;
		this.grade = grade;
		this.percent = percent;
	}
	
	public Utility_List() {
		roll = 10;
		name = "Devansh";
		grade = 10;
		percent = 40;	
	}
	
	public void createList() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Roll no :");
		roll = sc.nextInt();
		System.out.println("Enter Student Name :");
		name = sc.next();
		System.out.println("Enter Grade :");
		grade = sc.nextInt();
		System.out.println("Enter Percentage :");
		percent = sc.nextDouble();
	}
	
	public void printList(List<Utility_List> e) {
		System.out.println("Student Details");
		for(int i=0;i<e.size();i++) {
			System.out.println(e.get(i).roll+"\t"+e.get(i).name+"\t"+e.get(i).grade+"\t"+e.get(i).percent);
		}
		System.out.println();
	}
	
	@Override
	public int compareTo(Utility_List o) {
		// TODO Auto-generated method stub
		return Double.compare(this.percent, o.percent);
	}
}

class Utility_Report {
	String name;
	int percent;
	
	public void display(List<Utility_List> e)
 {
		TreeMap<String, Double> maap = new TreeMap<>();
        for (Utility_List u1 : e) {
            maap.put(u1.name, u1.percent);
        }
        for (Entry<String, Double> temp : maap.entrySet()) {
            System.out.println(temp.getKey() + "---> " + temp.getValue());
        }
		}
 }

class UseComparater implements Comparator<Utility_List> {

	@Override
	public int compare(Utility_List o1, Utility_List o2) {
		// TODO Auto-generated method stub
		Double.compare(o1.percent, o2.percent);
		Integer.compare(o1.grade, o2.grade);
		return 0;
	}
	
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Utility_List> e = new ArrayList<Utility_List>();
		Scanner sc = new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("Enter Choice : ");
			System.out.println("1. Add Student Details");
			System.out.println("2. Show Student Details");
			System.out.println("3. UTILITY REPORT");
			System.out.println("4. EXIT");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				Utility_List e1 = new Utility_List();
				e1.createList();
				e.add(e1);
				break;
			case 2:
				Utility_List e2 = new Utility_List();
				e.sort(null);
			//	Collections.sort(e);
		        Collections.sort(e, new UseComparater());
				e2.printList(e);				
				break;
			case 3:
				Utility_Report e3 = new Utility_Report();
				e3.display(e);
				break;
			case 4:
				System.exit(0);
			}
		}
	}

}

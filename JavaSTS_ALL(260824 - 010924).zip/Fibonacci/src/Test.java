import java.util.Scanner;

class fibonacci {
	public void fibo(int n) {
		int a = 0;
		int b = 1;
		for (int i=0;i<n;i++) {
			System.out.println(a + b);
			int c = a + b;
			a = b;
			b = c;
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		fibonacci f1 = new fibonacci();
		f1.fibo(num);
	}
}

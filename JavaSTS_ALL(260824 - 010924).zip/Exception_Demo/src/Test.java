/*Create a class Account with -
Instance variable - balance
Class methods - deposite/withdraw
User withdrawal limit on one transaction is Rs.15000/-
Throw and Handle Exceptions -
1. OverLimit - when user tries to withdraw more than Rs. 15000/- in a transaction
2. InsufficientBalance - When user withdrawal amount is more than existing balance
Refer class Account implemented in question 19. Make its methods synchronized to avoid 
thread interference
 */
class Account {
	protected double balance;

	public Account(double balance) {
		super();
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		balance = balance + amount;
	}
	
	public void withdraw(double amount) throws Exception {
		if(amount>balance) {
			throw new Exception("Insufficient Balance");
		}
		else if(amount>15000) {
			throw new Exception("OverLimit");
		}
		else {
			balance = balance - amount;
			System.out.println("Amount Withdrawn");
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account a1 = new Account(50000);
		a1.deposit(1000);
		System.out.println("Amount Deposited");
		try {
			a1.withdraw(15900);
			System.out.println(a1.balance);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println(e);		
			}
	}

}

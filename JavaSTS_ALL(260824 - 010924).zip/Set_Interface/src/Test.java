// HashSet
// TreeSet
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> hashset = new HashSet<>();
		hashset.add("Aryan");
		hashset.add("Devansh");
		hashset.add("Sakshi");
		hashset.add("Aryan"); // Duplication is not allowed
		System.out.println(hashset); // No order is preserved
		
		Set<String> treeset = new TreeSet<>();
		treeset.add("Aryan");
		treeset.add("Aryan"); // Duplication is not allowed
		treeset.add("Sakshi");
		treeset.add("Devansh");
		System.out.println(treeset);  // Order is sorted data
		
		for(String name:treeset) {
			System.out.println(name);
		}
		for(String name:hashset) {
			System.out.println(name);
		}
		System.out.println();
		
		Set<String> linkedset = new LinkedHashSet<>();
		linkedset.add("Devansh");
		linkedset.add("Sakshi");
		linkedset.add("Aryan");
		linkedset.add("Aryan"); // Duplication not allowed
		System.out.println(linkedset); // Order is preserved

	}

}

// Display a filled circle in a frame. Make this circle to move/toggle between left and right walls of 
// frame. Use multithreading

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;

@SuppressWarnings("serial")
class MoviCirC extends Frame implements Runnable {
	 int x1, x2;
	 Thread a1, t2;
	 boolean mr = true;
	
	public MoviCirC() {
		x1 = 100;
		x2 = 400;
		Thread a1 = new Thread(this, "a1");
	//	Thread t2 = new Thread(this, "t2");
		a1.start();
	//	t2.start();		
	}
	
	public void paint(Graphics g) {
		g.setColor(Color.RED);
		g.fillOval(x1, 200, 100, 100);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			if (mr) {
				x1++;
				try {
					Thread.sleep(10);
				}
				catch(Exception e) {
					// e.printStackTrace();
			}
				if(x1+100 > getWidth()) {
					mr = false;
				}
				}
			
			else {
					x1--;
					try {
						Thread.sleep(10);
					}
					catch(Exception e) {
						// e.printStackTrace();
				}
					if (x1<0) {
						mr = true;
					}
					}
			repaint();
			}
		}
	}
			
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MoviCirC mc1 = new MoviCirC();
		mc1.setSize(500, 500);
		mc1.setVisible(true);
		}

}

class nimal { // Method Overriding  
	public void sound() {
		System.out.println("Animal Makes sound");
	}
}
class dog1 extends nimal {  //Parent class, child class have same method names with difeerent explanation.
	public void sound() {  
		System.out.println("Dog Barks");
	}
}
public class Test2 {
	public static void main(String[] args) {
		nimal a1 = new nimal();
		a1.sound(); // Parent class method is called.
		nimal a2 = new dog1();
		a2.sound();  // Child class is called using Parent class. Output is of child class for same method.
		dog1 a3 = new dog1();
		a3.sound();  // Child Class method is called. Parent class cannot be called using child class.
	}
}

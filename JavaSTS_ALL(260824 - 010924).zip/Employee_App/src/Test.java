import in.mindcraft.SalesPerson;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Wage_Employee w1 = new Wage_Employee(11, "Devansh", 22, 9, 2002, 20, 200);
//		Wage_Employee w2 = new Wage_Employee();
//		w1.show();
//		System.out.println();
//		w2.show();
		SalesPerson s1 = new SalesPerson(11, "Devansh", 26, 8, 2002, 10, 2000, 50, 10);
		s1.show();
	}

}

import java.util.Scanner;

class Factorial{
	int i;
	int f = 1;
	public void factor() {
		System.out.println("Enter Number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		for(i=1;i<=num;i++) {
			f = f*i;
			
		System.out.println("Factorial of " + num +" is:" + f);
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Factorial test = new Factorial();
		test.factor();
	}

}
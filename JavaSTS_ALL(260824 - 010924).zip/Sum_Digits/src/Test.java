import java.util.Scanner;

class sum_digits {
	int b = 0;
	int temp = 0;
	public void sum(int a) {
		while (a>0) {
			temp = a%10;
			b = b+temp;
			a=a/10;
		}
	System.out.println(b);
	}
}
public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number");
		int num = sc.nextInt();
		sum_digits s1 = new sum_digits();
		s1.sum(num);
	}
}

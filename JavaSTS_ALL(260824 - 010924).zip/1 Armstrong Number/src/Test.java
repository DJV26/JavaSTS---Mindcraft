import java.util.Scanner;

class Armstrong {
	int a;
	
	public void check(int a) {
		int temp, b = 0;
		int num = a;
		while (a>0) {
			temp = a%10;
			b = b + temp*temp*temp;
			System.out.println(b);
			a=a/10;
		}
		if(b==num) {
			System.out.println("ARMSTRONG");
		}
		else {
			System.out.println("NOT ARMSTRONG");
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number to be checked");
		int a = sc.nextInt();
		Armstrong a1 = new Armstrong();
		a1.check(a);
	}

}

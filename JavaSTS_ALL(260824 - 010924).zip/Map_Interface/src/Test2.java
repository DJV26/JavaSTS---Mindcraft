// Map - TreeMap
	import java.util.TreeMap;
	import java.util.Map;
	public class Test2 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Map<Integer, String> m1 = new TreeMap<>();
//			m1.put(null, "Nikhil");
			m1.put(1,"Devansh");
			m1.put(3,"Sakshi");
			m1.put(2,"Aryan");
			m1.put(0, "Sameep");
			m1.put(0, "Sarvagya");
//			m1.put(null, "Shashwat"); 
			m1.put(4, null);		// Null key not allowed
			System.out.println(m1);  // Ordered by key, Value overriden if same key used again at key's original place
		}
}


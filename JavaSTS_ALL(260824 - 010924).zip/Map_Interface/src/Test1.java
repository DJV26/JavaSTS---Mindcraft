// Map - LinkedHashMap
import java.util.LinkedHashMap;
import java.util.Map;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, String> m1 = new LinkedHashMap<>();
		m1.put(null, "Nikhil");
		m1.put(1,"Devansh");
		m1.put(3,"Sakshi");
		m1.put(2,"Aryan");
		m1.put(0, "Sameep");
		m1.put(null, "Shashwat");
		m1.put(4, null);
		System.out.println(m1);  // Order is preserved, Value overriden if same key used again at key's original place
	}							   //(Insertion Order)

}

public class CktPlayer implements printable {
	private String name;
	private int runs;
	
	
	
public CktPlayer(String name, int runs) {
		this.name = name;
		this.runs = runs;
	}

@Override
	public void print() {
		System.out.println("Name :" +name );
		System.out.println("Runs :" +runs);
	}
}

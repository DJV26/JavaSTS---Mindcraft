interface printable {
	 void print();		
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CktPlayer c1 = new CktPlayer("Sachin Tendulkar", 10000);
        FtPlayer f1 = new FtPlayer("Cristiano Ronaldo", 1000);
        c1.print();
        f1.print();
	}

}

// Iterator - Needs to be declared after the list/set data type has all the data

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test3 {
	public static void main(String[] args) {
		List<String> list1 = new ArrayList<>();
		list1.add("Apple");
		list1.add("Banana");  // Adds to list at further indexes
		list1.add("Orange");
		System.out.println(list1);
		list1.add(1,"Guava");  // Adds to list at given index in int
		System.out.println(list1);
		Iterator<String> it1 = list1.iterator(); 
		while(it1.hasNext()) {
			String l = it1.next();
			System.out.println(l);
		}
	}
}

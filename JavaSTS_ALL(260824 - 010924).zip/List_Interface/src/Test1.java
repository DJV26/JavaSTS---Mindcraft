// Vector List - not popular against ArrayList
import java.util.Vector;
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Integer> v1 = new Vector<>();
		v1.add(1);
		v1.add(6);
		v1.add(90);
		v1.add(5);
		System.out.println(v1);
		v1.sort(null);
		System.out.println(v1);
	}

}

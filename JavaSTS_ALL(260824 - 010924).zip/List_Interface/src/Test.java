// ArrayList

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1 = new ArrayList<>();
		list1.add("Apple");
		list1.add("Banana");  // Adds to list at further indexes
		list1.add("Orange");
		System.out.println(list1);
		list1.add(1,"Guava");  // Adds to list at given index in int
		System.out.println(list1);
		list1.remove(0);  // Removes from list at given index
		System.out.println(list1);
		list1.remove("Banana");  // Removes from list first occurence of object
		System.out.println(list1);
		list1.add("Orange");
		System.out.println(list1);
		list1.remove("Orange");
		System.out.println(list1);
		boolean isp = list1.contains("Guava");  // Gives true/false whether object is present or not, can't use index
		System.out.println(isp);
		System.out.println(list1.size());  // returns size of list
		list1.sort(null);
		System.out.println(list1);
	}
	
}

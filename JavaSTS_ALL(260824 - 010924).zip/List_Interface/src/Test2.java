// LinkedList - Frequent addition and deletion faster, Easy Traversal in both directions

import java.util.LinkedList;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> linkls = new LinkedList<>();
		linkls.add("Devansh");
		linkls.add("Aryan");
		linkls.add("Sakshi");
		linkls.add("Nikhil");
		linkls.add("Gandhar");
		System.out.println(linkls);
	}
}


class vehicle implements Cloneable{
	private double cost;
	private int vno;
	private String vname;
	
	public vehicle(double cost, int vno, String vname) {
		super();
		this.cost = cost;
		this.vno = vno;
		this.vname = vname;
	}
	
	public vehicle() {
		cost = 0;
		vno = 0;
		vname = "";
	}
	
	public void show() {
		System.out.println(vname+" "+vno+" "+cost);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

}
public class Test {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		vehicle v1 = new vehicle(1000, 2, "Maruti");
		v1.show();
		vehicle v2 = (vehicle)v1.clone();
		v2.show();
	}

}

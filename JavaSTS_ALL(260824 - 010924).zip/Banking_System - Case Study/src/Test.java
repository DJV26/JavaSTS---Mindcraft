import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

class Account {
	private int acno;
	private String name;
	private double balance;
    private List<String> TransactionHistory;

	public Account(int acno, String name, double balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
        this.TransactionHistory = new ArrayList<>();
	}

	public int getAcno() {
		return acno;
	}

	public void setAcno(int acno) {
		this.acno = acno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void deposit(double DepositAmt) {
        balance = balance + DepositAmt;
        RecordTransaction("Deposited: " + DepositAmt);
	}

	public List<String> GetTransactionHistory() {
        return TransactionHistory;
	}

	public void withdraw(double WithdrawAmt) {
        if (WithdrawAmt > balance) {
            System.out.println("Insufficient balance.");
        }
        balance = balance - WithdrawAmt;
        RecordTransaction("Withdrawn: " +WithdrawAmt);
	}

	private void RecordTransaction(String transaction) {
        if (TransactionHistory.size() >= 5) {
           TransactionHistory.remove(0);
        }
        TransactionHistory.add(transaction);
	}

	@Override
	public String toString() {
		return "Account [acno=" +acno+ ", name=" +name+ ", balance=" +balance+ "]";
	}
	
}

class Banking {
	private Map<Integer, Account> accounts;
	
	public Banking() {
		accounts = new TreeMap<>();
	}

	public void CreateAccount(int acno, String acname, double balance) {
		Account NewAccount = new Account(acno, acname, balance);
		accounts.put(acno, NewAccount);
		System.out.println("ACCOUNT CREATED");
	}

	public void SearchAccountByName(String name) {
		boolean accou = false;
		for (Account acc : accounts.values()) {
            if (acc.getName().contains(name)) {
                System.out.println(acc);
                accou = true;
            }
		}
		if (accou==false) {
            System.err.println("No Account found: " + name);
        }
	}

	public void SearchAccountByNumber(int acno) {
        Account acc = accounts.get(acno);
        if (acc != null) {
            System.out.println(acc);
        } else {
            System.err.println("No account found for the account number: " + acno);
        }
	}

	public void ModifyAccount(int acno, String name) {
        Account acc = accounts.get(acno);
        if (acc == null) {
            System.err.println("Account not found.");
        }
        else {
        acc.setName(name);
        System.out.println("Account details updated.");
	}  }

	public void BalanceInquiry(int acno) {
        Account acc = accounts.get(acno);
        if (acc == null) {
            System.err.println("Account not found.");
        }
        else {
        System.out.println("Current balance: " +acc.getBalance());
    }  }

	public void CloseAccount(int acno) {
        Account acc = accounts.get(acno);
        if (acc == null) {
            System.err.println("Account not found.");
        }
        else {
        accounts.remove(acno);
        System.out.println("Account closed successfully.");
    } }

	public void Deposit(int acno, double DepositAmt) {
        Account acc = accounts.get(acno);
        if (acc == null) {
            System.err.println("Account not found.");
        }
        else {
        acc.deposit(DepositAmt);
        System.out.println("Amount Deposited :" +DepositAmt);
        System.out.println("New balance: " +acc.getBalance());
        }
    }

	public void Withdraw(int acno, double WithdrawAmt) {
        Account acc = accounts.get(acno);
        if (acc == null) {
            System.err.println("Account not found.");
        }
        else {
        	acc.withdraw(WithdrawAmt);
        	System.out.println("Amount Withdrawn :" +WithdrawAmt);
        	System.out.println("New balance: " +acc.getBalance());
    }
	}

	public void PrintMiniStatement(int acno) {
        Account acc = accounts.get(acno);
        if (acc == null) {
            System.err.println("Account not found.");
        }
        else {
        List<String> history = acc.GetTransactionHistory();
        System.out.println("Mini Statement for Account Number: " + acno);
        for (String transaction : history) {
            System.out.println(transaction);
        }
        }
	}

	public void Transfer(int FromAcc, int ToAcc, double TransferAmt) {
        Account fromAccount = accounts.get(FromAcc);
        Account toAccount = accounts.get(ToAcc);
        if (fromAccount == null || toAccount == null) {
            System.out.println("One or both accounts not found.");
        }
        else {
        	fromAccount.withdraw(TransferAmt);
        toAccount.deposit(TransferAmt);
        System.out.println("Transferred " + TransferAmt + " from " + FromAcc + " to " + ToAcc);
    }}
	}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
        Banking bank = new Banking();
        boolean b = true;

        while (b) {
            System.out.println("1. Login as Administrator");
            System.out.println("2. Login as Customer");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            switch (choice) {
            case 1:
                boolean admin = true;
                while (admin) {
                    System.out.println("1. Create Account");
                    System.out.println("2. Search Account by Name");
                    System.out.println("3. Search Account by Number");
                    System.out.println("4. Modify Account Details");
                    System.out.println("5. Balance Inquiry");
                    System.out.println("6. Close Account");
                    System.out.println("7. Logout");
                    System.out.println("Choose an option: ");
                    int AdminChoice = sc.nextInt();
                    switch (AdminChoice) {
                            case 1:
                                System.out.print("Enter Account Number: ");
                                int acno = sc.nextInt();
                                System.out.println("Enter Name: ");
                                String name = sc.next();
                                System.out.println("Enter Balance: ");
                                double balance = sc.nextDouble();
                                bank.CreateAccount(acno, name, balance);
                                break;
                            case 2:
                                System.out.println("Enter Name to Search: ");
                                name = sc.next();
                                bank.SearchAccountByName(name);
                                break;
                            case 3:
                                System.out.println("Enter Account Number to Search: ");
                                acno = sc.nextInt();
                                bank.SearchAccountByNumber(acno);
                                break;
                            case 4:
                                System.out.println("Enter Account Number to Modify: ");
                                acno = sc.nextInt();
                                System.out.println("Enter New Name: ");
                                name = sc.next();
                                bank.ModifyAccount(acno, name);
                                break;
                            case 5:
                                System.out.println("Enter Account Number for Balance Inquiry: ");
                                acno = sc.nextInt();
                                bank.BalanceInquiry(acno);
                                break;
                            case 6:
                                System.out.println("Enter Account Number to Close: ");
                                acno = sc.nextInt();
                                bank.CloseAccount(acno);
                                break;
                            case 7:
                                admin = false;
                                break;
                        }
                    } 
                break;

            case 2:
                boolean customer = true;
                while (customer) {
                    System.out.println("1. Deposit");
                    System.out.println("2. Withdraw");
                    System.out.println("3. Print Mini Statement");
                    System.out.println("4. Transfer");
                    System.out.println("5. Logout");
                    System.out.print("Choose an option: ");
                    int CustomerChoice = sc.nextInt();
                    switch (CustomerChoice) {
                    	case 1:
                    		System.out.print("Enter Account Number: ");
                    		int acno = sc.nextInt();
                            System.out.print("Enter Amount to Deposit: ");
                            double DepositAmt = sc.nextDouble();
                            bank.Deposit(acno, DepositAmt);
                            break;
                    	case 2:
                    		System.out.print("Enter Account Number: ");
                            acno = sc.nextInt();
                            System.out.print("Enter Amount to Withdraw: ");
                            double WithdrawAmt = sc.nextDouble();
                            bank.Withdraw(acno, WithdrawAmt);
                            break;
                    	case 3:
                            System.out.print("Enter Account Number: ");
                            acno = sc.nextInt();
                            bank.PrintMiniStatement(acno);
                            break;
                    	case 4:
                            System.out.print("Enter From Account Number: ");
                            int FromAcc = sc.nextInt();
                            System.out.print("Enter To Account Number: ");
                            int ToAcc = sc.nextInt();
                            System.out.print("Enter Amount to Transfer: ");
                            double TransferAmt = sc.nextDouble();
                            bank.Transfer(FromAcc, ToAcc, TransferAmt);
                            break;
                    	case 5:
                            customer = false;
                            break;
                        }
                }
                break;

            case 3:
                customer = false;
                System.exit(0);
        }
    }
}
}                              
                 
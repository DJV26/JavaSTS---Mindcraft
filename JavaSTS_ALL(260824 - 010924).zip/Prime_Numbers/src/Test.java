import java.util.Scanner;

class prime {
	public void identify(int n) {
		int ttt = 0;
		if (n>2) {
		for (int i=2; i<n; i++) {
			if (n%i == 0) {
				ttt = 1;
				break;
			}}
		if (ttt == 0) {
			System.out.println("PRIME");
		}
		else {
			System.out.println("NOT PRIME");
		
		}
		}
		if (n==2) {
			System.out.println("PRIME");
		}
		else { 
			System.out.println("ENTER IN 2-INFINITE");
		}
	}}



public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER NUMBER");
		int a = sc.nextInt();
		prime at = new prime();
		at.identify(a);
	}

}

import java.util.Scanner;

class rev {
	int b, temp = 0;
	public void rev_num(int a) {
		while (a>0) {
			temp = a%10;
			b = b*10 + temp;
			a=a/10;
		}
		System.out.println(b);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		rev a1 = new rev();
		a1.rev_num(a);
		}
}

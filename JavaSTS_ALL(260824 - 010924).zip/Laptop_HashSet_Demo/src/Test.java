import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

class Laptop implements Comparable<Laptop>{
	private int lid;
	String make;
	int cost;
	
	public Laptop(int lid, String make, int cost) {
		this.lid = lid;
		this.make = make;
		this.cost = cost;
	}
	
	public void show() {
		System.out.println(lid+" "+make+" "+cost);
	}

	@Override
	public int hashCode() {
		return Objects.hash(cost, lid, make);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Laptop other = (Laptop) obj;
		return Double.doubleToLongBits(cost) == Double.doubleToLongBits(other.cost) && lid == other.lid
				&& Objects.equals(make, other.make);
	}

	@Override
	public int compareTo(Laptop o) {
		// TODO Auto-generated method stub
		return Integer.compare(this.cost, o.cost);
	}
	
	
	
}

//class LaptopCompare implements Comparator<Laptop> {

//	@Override
//	public int compare(Laptop o1, Laptop o2) {
//		// TODO Auto-generated method stub
//		if(o1.getlid() > o2.getlid()) {
//			  
//		}
//		return 0;
//	}
	
//}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Laptop> l = new TreeSet<Laptop>();
		Laptop l1 = new Laptop(102, "HP", 200000);
		l.add(l1);
		l.add(new Laptop(101, "Samsung", 100000));
		System.out.println(l);
		
		List<Laptop> ll = new ArrayList<Laptop>();
		Laptop l2 = new Laptop(102, "HP", 200000);
		ll.add(l2);
		ll.add(new Laptop(101, "Samsung", 100000));
		Collections.sort(ll);
		System.out.println(ll);
		
		List<Laptop> lll = new ArrayList<Laptop>();
		Laptop l3 = new Laptop(102, "HP", 200000);
		lll.add(l3);
		lll.add(new Laptop(101, "Samsung", 100000));
		//Collections.sort(lll);
		System.out.println(lll);
		
		System.out.println(l.equals(ll));
		System.out.println(ll.equals(lll));
	}

}

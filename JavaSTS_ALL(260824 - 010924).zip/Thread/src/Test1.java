import java.util.Scanner;

class Threaa extends Thread{
	int a;
	public Threaa(int a) {
		this.a=a;
	}
	public void r() {
		for(int i=0; i<=2; i++) {
			System.out.println("Addition:"+i);
	}
}}

class Thream extends Thread {
	int m;
	public Thream(int m) {
		this.m = m;
	}
	public void r() {
		for(int i=0;i<=2;i++) {
			System.out.println("Multiplication:"+m*i);
		}
	}
}
	
public class Test1 {

	public static void main(String[] args) {

		int a,b;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value for addition:");
		a=sc.nextInt();
		System.out.println("Enter the value for multiplication table:");
		b=sc.nextInt();
		Threaa t1=new Threaa(a);
		t1.r();
		Thream t2=new Thream(b);
		t2.r();
		
	}
}


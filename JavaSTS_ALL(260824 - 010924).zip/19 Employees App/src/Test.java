import EmployeeApp.Manager;
import EmployeeApp.MarketingExecutive;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MarketingExecutive m1 = new MarketingExecutive(1, "Devansh", 10000, 100);
		Manager m2 = new Manager(2, "Aryan", 10000);
		m1.Cal_Salary();
		m1.display();
		System.out.println("MARKETING EXECUTIVE");
		System.out.println();
		m2.Cal_Salary();
		m2.display();
		System.out.println("MANAGER");
		
	}

}

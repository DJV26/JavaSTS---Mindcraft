package EmployeeApp;

public class Manager extends Employee{
	private double pall = 0.08;
	private double fall = 0.12;
	private double oall = 0.04;
	private int salary;
	
	public Manager() {
		pall = 0.08*salary;
		fall = 0.12*salary;
		oall = 0.04*salary;
	}

	public Manager(int id, String name, int salary) {
		super(id, name, salary);
		this.pall = 0.08*salary;
		this.fall = 0.12*salary;
		this.oall = 0.04*salary;
		this.salary = salary;
	}
	
	public void Cal_Salary() {
		double Gross = salary + pall + fall + oall;
		double pf = 0.125;
		double Net = Gross + salary*(1-pf) - salary;
		System.out.println("Gross Salary : "+Gross);
		System.out.println("Net Salary : "+Net);
	}
	
	public void display() {
		Employee e1 = new Employee();
		e1.display();
	}

}

package EmployeeApp;

public class Employee {

	private int id;
	private String name;
	private int salary;
	
	public Employee() {
		id = 1;
		name = "Devansh";
		salary = 10000;
	}

	public Employee(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	
	void display() {
		System.out.println("Employee ID :"+id);
		System.out.println("Employee Name :"+name);
		System.out.println("Employee Basic Salary :"+salary);
	}
	
}

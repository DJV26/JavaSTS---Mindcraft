import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

class person1 {
	private String name;
	private int age;
	
	public person1(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		person1 other = (person1) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
	
	
}
public class Test1 {
	public static void main(String[] args) {
		//List<Person> people = new ArrayList<Person>();
		person1 p1 = new person1("Aryan", 22);
		person1 p2 = new person1("Aryan", 22);
		person1 p3 = new person1("Sakshi", 24);
		
		System.out.println(p1.equals(p2));
		System.out.println(p1.equals(p3));
		System.out.println(p2.equals(p3));
	}
}

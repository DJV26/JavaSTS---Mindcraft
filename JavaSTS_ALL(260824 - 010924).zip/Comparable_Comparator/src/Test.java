import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
// Comparable - used to sort lists - uses compareto() method to compare ints.
class Person implements Comparable<Person> {
	String name;
	int age;
	
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		return Integer.compare(this.age, o.age);
	}
	
	
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Person> people = new ArrayList<Person>();
		people.add(new Person("Devansh", 22));
		people.add(new Person("Aryan", 21));
		people.add(new Person("Sakshi", 24));
		
		Collections.sort(people);  // Sorts based on age(what is compared)
		System.out.println(people);
	}

}

import java.util.Scanner;
class three {
	public void large(int a, int b, int c) {
		if (a>b) {
			if (a>c) {
				System.out.println(a);
			}
			else { 
				System.out.println(c);
			}
		}
		else {
				if (b>c) {
			System.out.println(b);
			}
		else { 
			System.out.println(c);
		}
	}
}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int a1, a2, a3;
		a1 = sc.nextInt();
		a2 = sc.nextInt();
		a3 = sc.nextInt();
		three tt = new three();
		tt.large(a1,a2,a3);
		
	}

}

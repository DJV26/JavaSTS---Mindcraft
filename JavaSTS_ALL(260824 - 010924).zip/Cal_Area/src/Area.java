class shape {
	int ar;
	public void area(int a, int b) {
		ar = a*b;
		System.out.println("Area of rectangle = " +ar);
	}
	public void area(int a) {
		ar = a*a;
		System.out.println("Area of square = " +ar);
	}
	public void area(double a) {
		double ar, pi;
		pi = 3.14;
		ar = pi*a*a;
		System.out.println("Area of circle = " +ar);
	}
}

public class Area {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		shape s1 = new shape();
		s1.area(10,4);
		s1.area(5);
		s1.area(2.2);
		s1.area(3f);
	}
}

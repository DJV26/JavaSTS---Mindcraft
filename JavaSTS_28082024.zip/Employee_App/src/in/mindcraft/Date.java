package in.mindcraft;

public class Date {
	private int dd,mm,yy; 
	
	public Date() {
		dd=1;
		mm=8;
		yy=2024;
	}

	public Date(int dd, int mm, int yy) {
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}
	
	public void show() {
		System.out.println("DOB :"+dd+"/"+mm+"/"+yy);
	}
}

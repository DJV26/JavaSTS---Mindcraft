package in.mindcraft;

public class Wage_Employee extends Employee{
	private int hours;
	private int rate;
	
	public Wage_Employee() {
		hours = 10;
		rate = 200;
	}

	public Wage_Employee(int empid, String ename, int dd, int mm, int yy, int hours, int rate) {
		super(empid, ename, dd, mm, yy);
		this.hours = hours;
		this.rate = rate;
	}
	
	public void show() {
		super.show();
		System.out.println("Hours: "+hours);
		System.out.println("Rate: "+rate);
		System.out.println("Salary of Wage Employee is :" +hours*rate);
	}
}

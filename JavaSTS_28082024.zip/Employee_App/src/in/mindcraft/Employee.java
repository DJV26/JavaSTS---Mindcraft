package in.mindcraft;

public class Employee {
	private int empid;
	private String ename;
	private Date dob;
	
	public Employee() {
		empid = 101;
		ename = "Devansh";
		dob = new Date();
	}

	public Employee(int empid, String ename, int dd, int mm, int yy) {
		this.empid = empid;
		this.ename = ename;
		this.dob = new Date(dd, mm, yy);
	}
	
	public void show() {
		System.out.println("Employee Id :" +empid);
		System.out.println("Employee Name :" +ename);
		dob.show();
	}
	
}

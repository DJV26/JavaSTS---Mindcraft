package in.mindcraft;

public class SalesPerson extends Wage_Employee{
	private int no;
	private int comm;
	private int hours;
	private int rate;
	
	public SalesPerson() {
		no = 100;
		comm = 20;
		hours = 10;
		rate = 900;
	}

	public SalesPerson(int empid, String ename, int dd, int mm, int yy, int hours, int rate, int no, int comm) {
		super(empid, ename, dd, mm, yy, hours, rate);
		this.no = no;
		this.comm = comm;
		this.hours = hours;
		this.rate = rate;
	}
	
	public void show() {
		super.show();
		System.out.println("No of items sold: "+no);
		System.out.println("Commission: "+comm);
		System.out.println("Commission Income :" +(no*comm));
		int tsal = (no*comm) + (hours*rate);
		System.out.println("Total Salary : "+tsal);
		System.out.println(hours);
		System.out.println(rate);
	}
}
// WageEmployee Salary = hours * rate
// SalesPerson Salary = hours*rate + sales*commission
package EmployeeApp;

public class MarketingExecutive extends Employee{
	private int kilo;
	private int tourall;
	private int teleall;
	private int salary;
	public MarketingExecutive() {
		kilo = 10;
		tourall = 5*kilo;
		teleall = 2000;
	}
	
	
	public MarketingExecutive(int id, String name, int salary, int kilo) {
		super(id, name, salary);
		this.kilo = kilo;
		this.tourall = 5*kilo;
		this.teleall = 2000;
		this.salary = salary;
	}



	public void Cal_Salary() {
		int Gross = salary + tourall + teleall;
		double pf = 0.125;
		double Net = Gross + salary*(1-pf) - salary;
		
		System.out.println("Gross Salary : "+Gross);
		System.out.println("Net Salary : "+Net);
	}
	
	public void display() {
		Employee e1 = new Employee();
		e1.display();
	}
}

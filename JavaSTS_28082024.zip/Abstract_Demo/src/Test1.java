interface showable {  // Interface is implemented in class
	void show(); 
}

interface printable {
	void print();
}

abstract class lib {
	abstract void store();
}

class doc extends lib implements showable, printable {  // Implements Needs to override

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("SHOW DOCUMENT");
	}

	@Override
	public void print() {
			// TODO Auto-generated method stub
			System.out.println("PRINT DOCUMENT");
	}

	@Override
	void store() {
		// TODO Auto-generated method stub
		System.out.println("STORE DETAILS");
	}
	
}

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		doc d = new doc();
		d.store();
		d.show();
		d.print();
	}

}

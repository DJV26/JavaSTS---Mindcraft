
abstract class Animal {  // only contains abstract and concrete(public void ...) method definition
						// explain the method in the class where the abstract class is extended
	abstract void sound();
}

class dog extends Animal {
	void sound() {
		System.out.println("BARKS - DOG");
	}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog d1 = new dog();
		d1.sound();
	}

}

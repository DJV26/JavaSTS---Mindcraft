

public class FtPlayer implements printable{
	private String Name;
	private int goals;
	
	
	public FtPlayer(String name, int goals) {
		Name = name;
		this.goals = goals;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
			System.out.println("Name :" +Name );
			System.out.println("Goals :" +goals);
	}
}

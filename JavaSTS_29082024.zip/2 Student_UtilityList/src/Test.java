import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Utility_List {
	int roll;
	String name;
	int grade;
	double percent;
	
	public Utility_List(int roll, String name, int grade, double percent) {
		this.roll = roll;
		this.name = name;
		this.grade = grade;
		this.percent = percent;
	}
	
	public Utility_List() {
		roll = 10;
		name = "Devansh";
		grade = 10;
		percent = 40;	
	}
	
	public void createList() {
		Scanner sc = new Scanner("System.in");
		System.out.println("Enter Roll no :");
		roll = sc.nextInt();
		System.out.println("Enter Student Name :");
		name = sc.next();
		System.out.println("Enter Grade :");
		grade = sc.nextInt();
		System.out.println("Enter Percentage :");
		percent = sc.nextDouble();
	}
	
	public void printList() {
		System.out.println("Student Details");
	}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Utility_List> e = new ArrayList<Utility_List>();
		Scanner sc = new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("Enter Choice : ");
			System.out.println("1. Add Student Details");
			System.out.println("2. Show Employee Details");
			System.out.println("3. EXIT");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				Utility_List e1 = new Utility_List();
				e1.createList();
				e.add(e1);
				break;
			case 2:
				for(int i=0;i<e.size();i++) {
					System.out.println(e.get(i).roll+" "+e.get(i).name+" "+e.get(i).grade+" "+e.get(i).percent);
				}
				System.out.println();
				break;
			case 3:
				System.exit(0);
			}
		}
	}

}

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Customer {
	int cid;
	int cidcnt;
	String cname;
	int []cart = new int[10]; 
	int []bills = new int[10];
	
	public Customer(int cid, String cname, int[] cart, int[] bills) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cart = cart;
		this.bills = bills;
	}
	
	public Customer() {
		super();
		cid = 0;
		cname = "l";
		cart = new int[10];
		bills = new int[10];
	}

	public void createCust() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Customer ID :");
		cid = sc.nextInt();
		System.out.println("Enter Customer Name :");
		cname = sc.next();
	}
	
	public void calCart() {
		
	}

}


class Product {
	int pid;
	String pname;
	int pprice;
	
	public Product(int pid, String pname, int pprice) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pprice = pprice;
	}
	
	public Product() {
		pid = 0;
		pname = "a";
		pprice = 0;
	}
	public void createProd() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Product ID :");
		pid = sc.nextInt();
		System.out.println("Enter Product Name :");
		pname = sc.next();
		System.out.println("Enter product price");
		pprice = sc.nextInt();
	}
	
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		List<Customer> clist = new ArrayList<Customer>();
		List<Product> plist = new ArrayList<Product>();
		while(true) {
			System.out.println("ENTER CUSTOMER OR ADMIN");
			System.out.println("1. Customer");
			System.out.println("2. Admin");
			int choice = sc.nextInt();

		switch(choice) {
		case 1:
			System.out.println("Enter Customer ID");
			int cid = sc.nextInt();
			System.out.println("PRODUCTS ARE");
			for(int i=0;i<plist.size();i++) {
				System.out.println("PID\tPNAME\t PPRICE");
				System.out.println(plist.get(i).pid+"\t"+plist.get(i).pname+"\t"+plist.get(i).pprice);
	}
			System.out.println("DO YOU WANT TO BUY PRODUCTS ?");
			System.out.println("1. YES, 2. NO");
			int b = sc.nextInt();
			while(true) {
			for(int i=0;i<plist.size();i++) {
				System.out.println("PID\tPNAME\t PPRICE");
				System.out.println(plist.get(i).pid+"\t"+plist.get(i).pname+"\t"+plist.get(i).pprice);
	}	
			int ccc;
			
			System.out.println("Enter Product ID to add to cart");
			
			break;
			}
			break;
		case 2: {
			System.out.println("Enter Username and Password");
			int uname = sc.nextInt();
			int pass = sc.nextInt();
//			Admin a1 = new Admin();
//			a1.check(uname, pass);
//			break;
			if(uname==1 && pass==1) {
				System.out.println("ADMIN LOGIN SUCCESSFUL");
				boolean t =true;
				while(t=true) {
					int ch = 0;
					System.out.println("1. Create Customer");
					System.out.println("2. Create Product");
					System.out.println("3. Show Customers");
					System.out.println("4. Show Products");
					System.out.println("5. EXIT ADMIN");
					ch = sc.nextInt();
				switch(ch) {
				case 1:
//					List<Customer> clist = new ArrayList<Customer>();
					Customer c1 = new Customer();
					c1.createCust();
					clist.add(c1);
					break;
				case 2:
//					List<Product> plist = new ArrayList<Product>();
					Product p1 = new Product();
					p1.createProd();
					plist.add(p1);
					break;
				case 3:
					Customer c2 = new Customer();
					for(int i=0;i<clist.size();i++) {
						System.out.println("CID\tCNAME\t CCART\tCBILLS");
						System.out.println(clist.get(i).cid+"\t"+clist.get(i).cname+"\t"+clist.get(i).cart[i]+"\t"+clist.get(i).bills[i]);
					}
					break;
				case 4:
					Product p2 = new Product();
					for(int i=0;i<plist.size();i++) {
						System.out.println("PID\tPNAME\t PPRICE");
						System.out.println(plist.get(i).pid+"\t"+plist.get(i).pname+"\t"+plist.get(i).pprice);
			}		break;
				case 5:
					t=false;
					break;
			}
			break;
			}
				}
			else {
				System.out.println("ERROR");
break;			}}
				case 3:
				break;
	}
	}}}


import java.util.Scanner;
class even {
		int a;
	public void check() {
		System.out.println("Enter Number to be checked : ");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		if (a%2 == 0) {
			System.out.println("EVEN");
		}
		else {
			System.out.println("ODD");
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		even e1 = new even();
		e1.check();
	}

}

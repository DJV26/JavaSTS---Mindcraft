import java.util.Scanner;

class palindrome {
	public void palindrom(String text) {
		int i = 0;
		int flag = 0;
		int j = text.length() - 1;
		for (i=0;i<=j;i++) {
			if (text.charAt(i) != text.charAt(j-i)) {
				flag = 1;
			}
		}
		if (flag==0) { 
			System.out.println("PALINDROME");
		}
		else {
			System.out.println("NOT PALINDROME");
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string to check");
		String text = sc.next();
		palindrome p1 = new palindrome();
		p1.palindrom(text);
	}

}

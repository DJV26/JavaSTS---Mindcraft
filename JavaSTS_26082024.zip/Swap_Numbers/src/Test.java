import java.util.Scanner;
class swap {
	public void num(int a, int b) {
		int temp;
		temp = a;
		a = b;
		b = temp;
		System.out.println("a = " +a);
		System.out.println("b = " +b);
	}
	public void num1(int a, int b) {
		a = a-b;
		b = a+b;
		a = b-a;
		System.out.println("a = " +a);
		System.out.println("b = " +b);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a");
		int a = sc.nextInt();
		System.out.println("Enter b");
		int b = sc.nextInt();
		
		swap s1 = new swap();
		s1.num(a, b);
		s1.num1(a, b);
	}
}

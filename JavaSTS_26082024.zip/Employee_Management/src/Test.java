import java.util.Scanner;

class Employee { 
	int EmployeeID;
	String name;
	String department;
	int salary;
	public void Cal_Bonus(int id, int bonusp, int salary, String name, String department) { 
		int bonus = salary*bonusp/100;
		System.out.println("Bonus Amount is " +bonus);
		System.out.println("Employee ID : " +id);
		System.out.println("Employee Name : " +name);
		System.out.println("Employee Department : " +department);
		System.out.println("Salary after Bonus is " +(bonus+salary));

	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee ID");
		int id = sc.nextInt();
		System.out.println("Enter Employee Name");
	    String name = sc.next();
		System.out.println("Enter Employee Department");
	    String dept = sc.next();
		System.out.println("Enter Bonus Percentage");
		int bonusp = sc.nextInt();
		System.out.println("Enter Salary");
		int salary = sc.nextInt();
		Employee e1 = new Employee();
		e1.Cal_Bonus(id,bonusp,salary,name, dept);
	}
}

import java.util.Scanner;

class Banking_Details {
	int Account_Number;
	String Account_Name;
	int Balance;
	public void Deposit(int acno, int damount, int balance) {
		Balance = balance + damount;
		System.out.println("Balance is " +Balance);
	}
	public void Withdraw(int acno, int wamount, int balance) {
		if (balance<=wamount) {
			Balance = Balance - wamount;
		}
		else {
			System.out.println("Balance is less than Withdrawal Amount.");
		}
		System.out.println("Balance is " +Balance);
	}
	public void Check_Balance(int acno, int balance) {
		System.out.println("Balance is " +balance);
	}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Acccount Number");
		int acno = sc.nextInt();
		System.out.println("Enter Balance");
		int balance = sc.nextInt();
		System.out.println("Enter Deposit or Withdraw or Check_Balance");
		String opn = sc.next();
		Banking_Details b1 = new Banking_Details();
		switch(opn) {
		case "Deposit" :
			System.out.println("Enter Deposit Amount");
			int damount = sc.nextInt();
			b1.Deposit(acno, damount, balance);
			break;
		 case "Withdraw":
				System.out.println("Enter Withdrawal Amount");
				int wamount = sc.nextInt();
				b1.Withdraw(acno, wamount, balance);
				break;
		  case "Check_Balance":
				b1.Check_Balance(acno, balance);
			    break;
		}
		}

}

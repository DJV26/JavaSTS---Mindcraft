import java.util.Scanner;
class add
{
	int a, b, c;
	Scanner sc = new Scanner(System.in);
//	public void addition()
//	{
//		a = 10;
//		b = 5;
//		c = a + b;
//		System.out.println(c);
//	}
	public void subtraction() {
		a = sc.nextInt();
		b = sc.nextInt();
		c = a - b;
		System.out.println("Subtartction is " +c);
	}
	public void addition() {
		a = sc.nextInt();
		b = sc.nextInt();
		c = a + b;
		System.out.println("Addition is " +c);
	}
	public void mul() {
		a = sc.nextInt();
		b = sc.nextInt();
		System.out.println("PRODUCT IS " +a*b);
	}
	public void division() {
		a = sc.nextInt();
		b = sc.nextInt();
		double c;
		try {
			c = a/b;
			System.out.println("Division is " +c);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
}

public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		add a1 = new add();
		String typ;
		System.out.println("Select add, sub, mul, div");
		Scanner sc = new Scanner(System.in);
		typ = sc.next();
		switch (typ) {
		  case "add":
			    a1.addition();
			    break;
		  case "sub":
			    a1.subtraction();
			    break;
		  case "mul":
			    a1.mul();
			    break;
		  case "div":
			    a1.division();
			    break;
		}
	}
}


